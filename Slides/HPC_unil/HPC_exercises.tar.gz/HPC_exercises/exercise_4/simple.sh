#!/bin/bash
echo "The name of the machine executing this script is:"
hostname
exit 0

