#!/bin/env R

# Get R version and nickname and print it to the terminal.
r_version = R.Version()
cat("\nYou are using ", r_version$version.string, 
    ", also known as '", r_version$nickname, "'. \n", sep='')

# Warn user if running the system's defaut R version.
if(paste(r_version$major, r_version$minor, sep='.') == "3.5.2"){
    cat("WARNING: This seems to be the system's default", 
        "version of R. Make sure you loaded the R module. \n")
}

