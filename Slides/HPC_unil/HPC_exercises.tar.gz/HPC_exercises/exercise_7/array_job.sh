#!/bin/bash

# SLURM options:
#SBATCH --account <your_account>
#SBATCH --output %x_%A-%a.out
#SBATCH --error %x_%A-%a.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --mail-user <username>@unil.ch
#SBATCH --mail-type ALL
#SBATCH --export=NONE


# Load modules needed for job.
# Reminder: you can search for software with the "vit_soft" command.
module add Bioinformatics/Software/vital-it
module add R/3.5.1


# Job commands.
# Filter input data to keep only prime numbers.
Rscript ./filter__prime_numbers.R <input file to process>
exit 0

