####################################################################################################
# Read input file and keep only prime numbers.
# *******************************************

# Define function to check if a number is prime or not.
# ****************************************************
library(parallel)
is_prime_number <- function(number){
    if(number <= 1) return(FALSE)
    if(number == 2) return(TRUE)
    return(!any(sapply(2:(number-1), FUN=function(x) (number %% x) == 0 )))
}


# Load user input file.
# ********************
core_nb = 2
args = commandArgs(trailingOnly=TRUE) 
if(length(args) > 0){
    input_file = args[[1]]
    input_list = read.table(input_file, h=F, sep='\t', as.is=T)[,1]
} else{
    stop("missing user input.")
}


# Search which numbers in the list are prime.
# ******************************************
prime_index = which(unlist(mclapply(input_list, is_prime_number, mc.cores=core_nb)))
write.table(x=input_list[prime_index], 
            file=sub('.txt','_filtered.txt', input_file), 
            row.names=F, quote=F, col.names=F, sep='\t')


# Exit script.
quit(save='no')

####################################################################################################

