
# Create a matrix that uses 15GB of memory.
tmp = matrix(rexp(700000000, rate=.1), ncol=20)

# Suspend execution of script, so slurm has time to get the true
# memory usage of the job.
Sys.sleep(20)

