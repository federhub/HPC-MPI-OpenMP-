#!/bin/bash

# SLURM options:
#SBATCH --account <your_account>
#SBATCH --job-name primeNumbers
#SBATCH --partition normal
#SBATCH --output %x_%j.out
#SBATCH --error %x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 4
#SBATCH --mail-user <username>@unil.ch
#SBATCH --mail-type ALL
#SBATCH --export=NONE
#SBATCH --time 0-00:10:00


# Load modules needed for job.
# Reminder: you can search for software with the "vit_soft" command.
module add Bioinformatics/Software/vital-it
module add R/3.5.1


# Job commands.
# Run memory hog script.
Rscript ./hog_memory.R

# Find all prime numbers smaller or equal to 20'000.
Rscript ./compute_prime_numbers.R 20000 2
exit 0

