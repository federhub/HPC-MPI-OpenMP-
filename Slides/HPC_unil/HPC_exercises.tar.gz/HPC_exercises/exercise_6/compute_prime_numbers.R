####################################################################################################
# Compute prime numbers in the range 2:max_index using one or more processors.
# ***************************************************************************


# Define function to check if a number is prime or not.
# ****************************************************
library(parallel)
is_prime_number <- function(number){
    if(number <= 1) return(FALSE)
    if(number == 2) return(TRUE)
    return(!any(sapply(2:(number-1), FUN=function(x) (number %% x) == 0 )))
}


# Get optional user input.
# ***********************
# Note: 7919 as max_index will return the first 1000 prime numbers. 17389 returns the first 2000.
max_index = 7920           # this will return the first 1000 prime numbers.
core_nb = 1
args = commandArgs(trailingOnly=TRUE) 
if(length(args) > 0){
    max_index = as.numeric(args[[1]])  # largest value to check for prime number.
    core_nb = as.numeric(args[[2]])    # number of cores to use for computing.
} 


# Compute and print prime numbers.
# *******************************
cat('Computing prime numbers from 2 to ', max_index, '\n', sep='')
prime_list = which(unlist(mclapply(2:max_index, is_prime_number, mc.cores=core_nb))) + 1
for(i in prime_list) cat(i, '\n', sep='')

# Exit script.
quit(save='no')

####################################################################################################
